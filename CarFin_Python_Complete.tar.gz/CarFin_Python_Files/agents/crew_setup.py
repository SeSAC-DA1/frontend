"""
CrewAI Multi-Agent System for CarFin
Two specialized agents: Vehicle Recommendation + Finance Consultation
"""
import os
from typing import Dict, List, Any
from crewai import Agent, Task, Crew, Process
from ml.recommendation_engine import CarRecommendationEngine
import logging

# Import OpenAI integration setup from blueprint
from openai import OpenAI

# the newest OpenAI model is "gpt-5" which was released August 7, 2025.
# do not change this unless explicitly requested by the user
OPENAI_API_KEY = os.environ.get("OPENAI_API_KEY")
openai_client = OpenAI(api_key=OPENAI_API_KEY)

class CarFinAgents:
    """CarFin CrewAI Multi-Agent System"""
    
    def __init__(self):
        self.logger = self._setup_logger()
        self.recommendation_engine = CarRecommendationEngine()
        self.vehicle_agent = None
        self.finance_agent = None
        self.crew = None
        self._initialize_agents()
    
    def _setup_logger(self):
        """Set up logging"""
        logging.basicConfig(level=logging.INFO)
        return logging.getLogger(__name__)
    
    def _initialize_agents(self):
        """Initialize the two specialized agents"""
        try:
            # Load data for the recommendation engine
            if not self.recommendation_engine.load_data():
                self.logger.warning("Failed to load recommendation data")
            
            # Train the ML model
            if not self.recommendation_engine.train_model():
                self.logger.warning("Failed to train recommendation model")
            
            # Create Vehicle Recommendation Agent
            self.vehicle_agent = Agent(
                role="차량 추천 전문가",
                goal="사용자의 요구사항을 정확히 분석하여 PyCaret ML 기반으로 최적의 차량 3개를 추천하고 친근하게 설명",
                backstory="""
                자동차 업계에서 10년간 근무한 전문가입니다. 
                PyCaret ML 분석 능력을 보유하고 있으며, 고객의 라이프스타일과 예산을 고려한 
                맞춤형 차량 추천에 특화되어 있습니다.
                
                특히 20-30대 첫 차 구매자들의 심리를 잘 이해하며, 
                복잡한 기술 용어 대신 쉽고 친근한 언어로 설명하는 것을 중시합니다.
                """,
                verbose=True,
                allow_delegation=False,
                max_iter=3
            )
            
            # Create Finance Consultation Agent  
            self.finance_agent = Agent(
                role="자동차 금융 상담 전문가",
                goal="선택된 차량에 대해 대출, 리스, 할부 등 다양한 금융 옵션을 계산하고 최적의 방안을 제안",
                backstory="""
                자동차 금융 분야에서 8년간 근무한 전문가입니다.
                은행, 캐피탈, 리스 회사 등 다양한 금융기관의 상품에 정통하며,
                고객의 신용 상황과 현금 흐름을 고려한 맞춤형 금융 솔루션을 제공합니다.
                
                복잡한 금융 계산을 쉽게 설명하고, 고객이 부담 없이 이해할 수 있도록 
                월 납부액, 총 비용, 혜택 등을 명확하게 비교해드립니다.
                """,
                verbose=True,
                allow_delegation=False,
                max_iter=3
            )
            
            self.logger.info("Successfully initialized CarFin agents")
            
        except Exception as e:
            self.logger.error(f"Failed to initialize agents: {e}")
    
    def _parse_user_requirements(self, user_message: str) -> Dict[str, Any]:
        """Parse user message to extract structured requirements"""
        try:
            # Use GPT-5 to parse user requirements into structured format
            parse_prompt = f"""
            다음 사용자 메시지를 분석하여 차량 구매 요구사항을 JSON 형태로 추출해주세요.

            사용자 메시지: "{user_message}"

            다음 형태의 JSON으로 응답해주세요:
            {{
                "budget_max": 예산 상한선 (만원, 숫자만),
                "age_group": "20대" 또는 "30대" 등,
                "purpose": "출퇴근", "가족용", "레저" 등 주요 용도,
                "category": "Compact", "Mid-size", "SUV", "Luxury" 중 선호 카테고리,
                "fuel_type": "Gasoline", "Hybrid", "Electric" 중 연료 선호,
                "priorities": ["연비", "안전", "디자인", "가격"] 등 우선순위 배열,
                "experience": "첫차", "경험있음" 등 구매경험
            }}
            
            만약 명시되지 않은 정보가 있다면 일반적인 한국의 해당 연령대 기준으로 추정해주세요.
            """
            
            response = openai_client.chat.completions.create(
                model="gpt-5",
                messages=[{"role": "user", "content": parse_prompt}],
                response_format={"type": "json_object"}
            )
            
            import json
            response_content = response.choices[0].message.content
            if response_content:
                user_profile = json.loads(response_content)
            else:
                raise ValueError("OpenAI response content is empty")
            
            # Add user_id for tracking
            user_profile['user_id'] = f"user_{hash(user_message) % 10000}"
            
            return user_profile
            
        except Exception as e:
            self.logger.error(f"Failed to parse user requirements: {e}")
            # Return default profile
            return {
                "budget_max": 4000,
                "age_group": "20-30대",
                "purpose": "일반 주행",
                "category": "Compact",
                "fuel_type": "Gasoline",
                "priorities": ["가격", "연비"],
                "experience": "첫차",
                "user_id": "default_user"
            }
    
    def create_recommendation_task(self, user_message: str) -> Task:
        """Create vehicle recommendation task"""
        user_profile = self._parse_user_requirements(user_message)
        
        task_description = f"""
        사용자 요청: "{user_message}"
        
        분석된 사용자 프로필:
        - 예산: {user_profile.get('budget_max', '미지정')}만원 이하
        - 연령대: {user_profile.get('age_group', '20-30대')}
        - 주요 용도: {user_profile.get('purpose', '일반')}
        - 선호 카테고리: {user_profile.get('category', 'Compact')}
        - 연료 선호: {user_profile.get('fuel_type', 'Gasoline')}
        - 우선순위: {user_profile.get('priorities', ['가격', '연비'])}
        
        이 정보를 바탕으로 다음을 수행해주세요:

        1. PyCaret ML 추천 엔진을 사용하여 상위 3개 차량 추천
        2. 각 차량에 대해 선택 이유를 친근하고 이해하기 쉽게 설명
        3. 가격, 연비, 안전성 등 핵심 정보 제공
        4. 첫차 구매자도 쉽게 이해할 수 있는 언어 사용

        응답 형태:
        - 추천 차량 1: [차량명] - [가격] - [핵심 장점과 추천 이유]
        - 추천 차량 2: [차량명] - [가격] - [핵심 장점과 추천 이유]  
        - 추천 차량 3: [차량명] - [가격] - [핵심 장점과 추천 이유]
        
        마지막에 어떤 차량이 가장 마음에 드시는지 물어보고 금융 상담을 안내해주세요.
        """
        
        return Task(
            description=task_description,
            agent=self.vehicle_agent,
            expected_output="사용자 맞춤형 차량 3개 추천과 친근한 설명"
        )
    
    def create_finance_task(self, selected_car_id: str, user_budget: int) -> Task:
        """Create finance consultation task"""
        task_description = f"""
        선택된 차량 ID: {selected_car_id}
        사용자 예산: {user_budget}만원

        이 차량에 대해 다음 금융 옵션들을 계산하고 비교해주세요:

        1. 현금 일시불
        2. 은행 대출 (5년 기준)
        3. 캐피탈 할부 (5년 기준) 
        4. 리스 (4년 기준)

        각 옵션별로 제공해주세요:
        - 월 납부액
        - 총 지급 비용
        - 장점과 단점
        - 적합한 고객 유형

        사용자의 예산 상황을 고려하여 가장 적합한 옵션 1-2개를 추천하고 이유를 설명해주세요.
        복잡한 금융 용어보다는 실생활에서 이해하기 쉬운 표현을 사용해주세요.
        """
        
        return Task(
            description=task_description,
            agent=self.finance_agent,
            expected_output="선택 차량의 다양한 금융 옵션 비교와 맞춤 추천"
        )
    
    def get_vehicle_recommendations(self, user_message: str) -> Dict[str, Any]:
        """Get vehicle recommendations from the multi-agent crew"""
        try:
            # Parse user requirements for ML engine
            user_profile = self._parse_user_requirements(user_message)
            
            # Get ML-based recommendations
            ml_recommendations = self.recommendation_engine.get_recommendations(
                user_profile, n_recommendations=3
            )
            
            # Create recommendation task
            rec_task = self.create_recommendation_task(user_message)
            
            # Ensure agent is properly initialized
            if self.vehicle_agent is None:
                raise ValueError("Vehicle agent is not initialized")
            
            # Create crew with just the vehicle agent for this task
            crew = Crew(
                agents=[self.vehicle_agent],
                tasks=[rec_task],
                process=Process.sequential,
                verbose=True
            )
            
            # Execute the crew
            agent_response = crew.kickoff()
            
            return {
                "status": "success",
                "agent_response": str(agent_response),
                "ml_recommendations": ml_recommendations,
                "user_profile": user_profile
            }
            
        except Exception as e:
            self.logger.error(f"Vehicle recommendation failed: {e}")
            return {
                "status": "error",
                "message": f"추천 시스템에 오류가 발생했습니다: {str(e)}",
                "ml_recommendations": [],
                "user_profile": {}
            }
    
    def get_finance_consultation(self, car_id: str, user_budget: int) -> Dict[str, Any]:
        """Get finance consultation from the finance agent"""
        try:
            # Get car details
            car_details = self.recommendation_engine.get_car_details(int(car_id))
            if not car_details:
                return {
                    "status": "error",
                    "message": "선택하신 차량 정보를 찾을 수 없습니다."
                }
            
            # Create finance task
            finance_task = self.create_finance_task(car_id, user_budget)
            
            # Ensure agent is properly initialized
            if self.finance_agent is None:
                raise ValueError("Finance agent is not initialized")
            
            # Create crew with just the finance agent
            crew = Crew(
                agents=[self.finance_agent],
                tasks=[finance_task],
                process=Process.sequential,
                verbose=True
            )
            
            # Execute the crew
            agent_response = crew.kickoff()
            
            # Calculate actual finance options
            finance_options = self._calculate_finance_options(car_details['price'], user_budget)
            
            return {
                "status": "success",
                "agent_response": str(agent_response),
                "car_details": car_details,
                "finance_options": finance_options
            }
            
        except Exception as e:
            self.logger.error(f"Finance consultation failed: {e}")
            return {
                "status": "error", 
                "message": f"금융 상담 중 오류가 발생했습니다: {str(e)}"
            }
    
    def _calculate_finance_options(self, car_price: int, user_budget: int) -> List[Dict]:
        """Calculate actual finance options"""
        try:
            options = []
            
            # Cash purchase
            options.append({
                "type": "현금 일시불",
                "monthly_payment": 0,
                "total_cost": car_price,
                "down_payment": car_price,
                "description": "차량 소유권 즉시 획득, 이자 부담 없음"
            })
            
            # Bank loan (5 years, 4% interest)
            loan_amount = min(car_price * 0.9, car_price - 500)  # 90% 대출 또는 500만원 자부담
            if loan_amount > 0:
                monthly_rate = 0.04 / 12
                months = 60
                monthly_payment = loan_amount * (monthly_rate * (1 + monthly_rate)**months) / ((1 + monthly_rate)**months - 1)
                total_cost = monthly_payment * months + (car_price - loan_amount)
                
                options.append({
                    "type": "은행 대출 (5년)",
                    "monthly_payment": int(monthly_payment),
                    "total_cost": int(total_cost),
                    "down_payment": car_price - loan_amount,
                    "description": "낮은 금리, 차량 소유권 획득"
                })
            
            # Capital installment (5 years, 6% interest)
            installment_months = 60
            monthly_rate = 0.06 / 12
            monthly_payment = car_price * (monthly_rate * (1 + monthly_rate)**installment_months) / ((1 + monthly_rate)**installment_months - 1)
            
            options.append({
                "type": "할부 (5년)",
                "monthly_payment": int(monthly_payment),
                "total_cost": int(monthly_payment * installment_months),
                "down_payment": 0,
                "description": "자기자본 부담 적음, 할부 완료 시 소유권 획득"
            })
            
            # Lease (4 years)
            lease_months = 48
            residual_value = car_price * 0.4  # 40% residual
            lease_payment = (car_price - residual_value + (car_price * 0.03)) / lease_months
            
            options.append({
                "type": "리스 (4년)",
                "monthly_payment": int(lease_payment),
                "total_cost": int(lease_payment * lease_months),
                "down_payment": car_price * 0.1,  # 10% down payment
                "description": "낮은 월 납부액, 계약 종료 시 반납 또는 구매 선택"
            })
            
            return options
            
        except Exception as e:
            self.logger.error(f"Finance calculation failed: {e}")
            return []

# Global instance
carfin_agents = CarFinAgents()